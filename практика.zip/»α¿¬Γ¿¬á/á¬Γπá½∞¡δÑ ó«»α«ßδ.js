document.addEventListener('DOMContentLoaded', function() {
    const questionsContainer = document.getElementById('questions-container');
    const newQuestionInput = document.getElementById('new-question');
    const newAnswerInput = document.getElementById('new-answer');
    const addButton = document.getElementById('add-button');

    // Функция для добавления вопроса на страницу
    function addQuestion(questionText, answerText) {
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('question');
        questionDiv.textContent = questionText;

        const answerDiv = document.createElement('div');
        answerDiv.classList.add('answer');
        answerDiv.textContent = answerText;

        questionDiv.addEventListener('click', function() {
            answerDiv.style.display = answerDiv.style.display === 'block' ? 'none' : 'block';
        });

        questionDiv.appendChild(answerDiv);
        questionsContainer.appendChild(questionDiv);
    }

    // Обработчик нажатия на кнопку "Добавить вопрос"
    addButton.addEventListener('click', function() {
        const questionText = newQuestionInput.value;
        const answerText = newAnswerInput.value;

        if (questionText && answerText) {
            addQuestion(questionText, answerText);
            newQuestionInput.value = ''; // Очищаем поля ввода
            newAnswerInput.value = '';
        } else {
            alert('Пожалуйста, заполните вопрос и ответ.');
        }
    });

    // Пример начальных вопросов (можно убрать)
    addQuestion('Что такое список в Python?', 'Список (list) - это упорядоченная изменяемая коллекция элементов.');
    addQuestion('Что такое словарь в Python?', 'Словарь (dict) - это неупорядоченная коллекция пар "ключ-значение".');
});
function saveQuestions() {
    const questions = [];
    const questionDivs = document.querySelectorAll('.question');
    questionDivs.forEach(questionDiv => {
        const questionText = questionDiv.firstChild.textContent; // Получаем только текст вопроса
        const answerDiv = questionDiv.querySelector('.answer');
        const answerText = answerDiv.textContent;
        questions.push({ question: questionText, answer: answerText });
    });
    localStorage.setItem('pythonQuestions', JSON.stringify(questions));
}


// Функция для загрузки вопросов из Local Storage
function loadQuestions() {
    const storedQuestions = localStorage.getItem('pythonQuestions');
    if (storedQuestions) {
        const questions = JSON.parse(storedQuestions);
        questions.forEach(question => {
            addQuestion(question.question, question.answer);
        });
    }
}

// Вызываем loadQuestions при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    //... существующий код

    loadQuestions(); // Загружаем сохраненные вопросы
});


addButton.addEventListener('click', function() {
    //... существующий код

     if (questionText && answerText) {
            addQuestion(questionText, answerText);
            saveQuestions(); // Сохраняем после добавления
            newQuestionInput.value = ''; // Очищаем поля ввода
            newAnswerInput.value = '';
        }

    //... существующий код
});
    const menuToggle = document.getElementById('menu-toggle');
    const menu = document.getElementById('menu');

    menuToggle.addEventListener('click', () => {
    if (menu.style.maxHeight) {
        menu.style.maxHeight = null;
    } else {
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
});