const starButtons = document.querySelectorAll('.starButton');

starButtons.forEach(button => {
    const starPath = button.querySelector('.starPath');

    button.addEventListener('click', function() {
        button.classList.add('clicked');
        starPath.setAttribute('fill', 'yellow');

        setTimeout(function() {
            button.classList.remove('clicked');
        }, 100);
    });
});

